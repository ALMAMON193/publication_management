(function($) {
  'use strict';
  $(function() {
    $('#profile-rating').barrating({
      theme: 'css-stars',
      showSelectedRating: false
    });
  });
})(jQuery);