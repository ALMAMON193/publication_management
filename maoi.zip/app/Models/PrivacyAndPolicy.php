<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PrivacyAndPolicy extends Model
{
    protected  $guarded  =[];
}
