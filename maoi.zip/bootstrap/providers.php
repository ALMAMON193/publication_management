<?php

return [
    App\Providers\AppServiceProvider::class,
    Tymon\JWTAuth\Providers\LaravelServiceProvider::class,
    Yajra\DataTables\DataTablesServiceProvider::class,
];
